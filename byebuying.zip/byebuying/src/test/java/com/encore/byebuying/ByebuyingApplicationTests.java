package com.encore.byebuying;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ByebuyingApplicationTests {

	@Test
	void contextLoads() {
	}

}
